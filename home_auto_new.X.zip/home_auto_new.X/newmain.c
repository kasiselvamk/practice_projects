/*
 * File:   newmain.c
 * Author: kasi
 *
 * Created on 5 January, 2022, 10:57 PM
 */
#include <util/delay.h>

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <stdlib.h>
#include <util/atomic.h>
#include <time.h>
#include <string.h>
#include <avr/pgmspace.h>

#include "usart.h"


FUSES = {
    .low = 0xFF, // LOW {SUT_CKSEL=EXTXOSC_8MHZ_XX_16KCK_14CK_65MS, CKOUT=CLEAR, CKDIV8=CLEAR}
    .high = 0xDE, // HIGH {BOOTRST=SET, BOOTSZ=256W_3F00, EESAVE=CLEAR, WDTON=CLEAR, SPIEN=SET, DWEN=CLEAR, RSTDISBL=CLEAR}
    .extended = 0xFD, // EXTENDED {BODLEVEL=2V7}
};

LOCKBITS = 0xFF; // {LB=NO_LOCK, BLB0=NO_LOCK, BLB1=NO_LOCK}



const time_t TOTAL_SUN_SET_OFFSET_IN_SEC[][31] = {
    {64418, 64451, 64485, 64519, 64553, 64587, 64621, 64655, 64689, 64723, 64757, 64790, 64824, 64857, 64889, 64922, 64954, 64986, 65018, 65049, 65080, 65110, 65140, 65169, 65198, 65227, 65255, 65282, 65309, 65336, 65361}
};


//#define BUFF_SIZE   25
//#define F_CPU 16000000UL

typedef unsigned long time_t;

time_t power_up_elapsed_s = 0;
char bufnow[80];
time_t systime = 0;
struct tm ts;

void setTime(time_t t);
char *now();
void setTodaySunsetOffset(int8_t t_mon, int8_t t_day);
void get_time_in_sec();
void init_timer();

void setTime(time_t t) {
    systime = t;
}

typedef struct {
    int8_t mon;
    int8_t day;
    int8_t hrs;
    int8_t min;
    int8_t sec;

} TODAY_SUNSET_OFFSET;

TODAY_SUNSET_OFFSET today_sunset_offset = {0};

void setTodaySunsetOffset(int8_t t_mon, int8_t t_day) {
    // uart_putint(t_mon);     /**< months since January - [ 0 to 11 ] */
    //uart_putint(t_day);    /**< day of the month - [ 1 to 31 ] */
    time_t t_mp = TOTAL_SUN_SET_OFFSET_IN_SEC[t_mon][t_day - 1];
    int t_hrs, t_min, t_sec, rem_tmp;
    t_hrs = t_mp / 3600;
    rem_tmp = t_mp % 3600;

    t_min = rem_tmp / 60;
    t_sec = rem_tmp % 60;
    uart_putint(t_hrs);
    uart_putc('\n');
    uart_putint(t_min);
    uart_putc('\n');
    uart_putint(t_sec);
    uart_putc('\n');
    today_sunset_offset.mon = t_mon;
    today_sunset_offset.day = t_day;
    today_sunset_offset.hrs = t_hrs;
    today_sunset_offset.min = t_min;
    today_sunset_offset.sec = t_sec;
}

char *now() {
    time_t current = 0;
    if (systime > 0) {
        PORTB |= (1 << PORTB1); // indicate time is set

        ATOMIC_BLOCK(ATOMIC_FORCEON) {
            current = systime + power_up_elapsed_s;
        }
        current = current - UNIX_OFFSET + 19800;

    } else {
        current = 19800;
    }
    //2022-01-23 11:55:17
    // Format time, "yyyy-mm-dd hh:mm:ss"
    ts = *localtime(&current);
    ts.tm_isdst = 0;
    if (ts.tm_year > 100 && today_sunset_offset.day == 0) { /**< years since 1900 */
        setTodaySunsetOffset(ts.tm_mon, ts.tm_mday);
    }
    memset(bufnow, 0, sizeof (bufnow));
    strftime(bufnow, sizeof (bufnow), "%Y-%m-%d %H:%M:%S\n", &ts);
    return bufnow;
}

ISR(TIMER1_COMPA_vect) {
    power_up_elapsed_s++;
}

void get_time_in_sec() {

    /* char uart_in_buff[21];
     uart_getln(uart_in_buff, sizeof (uart_in_buff));

    time_t val_long = strtoul(uart_in_buff, NULL, 10); //we will get sec as HEX so base 10.
    setTime(val_long); */
    setTime(1643043491UL);
}

void init_timer() {

    TCCR1B |= (1 << WGM12);
    TCNT1 = 0;
    OCR1A = 31249; //insert the comparision value.
    TIMSK1 |= (1 << OCIE1A); //enabling the compare match interrupt
    TCCR1B = _BV(CS12);

}

int main() {
    DDRB |= (1 << DDB1);
    PORTB &= ~(1 << PORTB1);

    uart_init(BAUD_CALC(115200)); // 8n1 transmission is set as default

    stdout = &uart0_io; // attach uart stream to stdout & stdin
    stdin = &uart0_io; // uart0_in and uart0_out are only available if NO_USART_RX or NO_USART_TX is defined
    sei(); // enable interrupts, library wouldn't work without this
    get_time_in_sec();
    init_timer();

    while (1) {
        _delay_ms(1000);
        now();

    }
    return 0;
}
