package com.agaramudala.zuul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;

import com.agaramudala.Config.RibbonConfiguration;

@EnableZuulProxy
@SpringBootApplication
@RibbonClient(name = "EUREKA-CLIENT", configuration = RibbonConfiguration.class)
public class ZuulApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZuulApplication.class, args);
	}
}
