package com.agaramudala.EurekaDiscoveryagaramudala;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Hello {

	
	@RequestMapping("/hi")
	  public String hi() {
 	    return String.format("%s, %s!", "kasi", "selvam");
	  }
}
