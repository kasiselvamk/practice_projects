package com.csrf.filters;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class CsrfCheckFilter
 */
@WebFilter("/CsrfServlet")
public class CsrfCheckFilter implements Filter {
	private static final String CSRF_TOKEN_NAME = "X-TOKEN";
	public static final String TARGET_ORIGIN_JVM_PARAM_NAME = "target.origin";


	/**
	 * Default constructor. 
	 */
	public CsrfCheckFilter() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}
	String accessDeniedReason;

	private URL targetOrigin;

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpReq = (HttpServletRequest) request;
		HttpServletResponse httpResp = (HttpServletResponse) response;
		String source = httpReq.getHeader("Origin");

		if (this.isBlank(source)) {
			//If empty then fallback on "Referer" header
			source = httpReq.getHeader("Referer");
			//If this one is empty too then we trace the event and we block the request (recommendation of the article)...
			if (this.isBlank(source)) {
				accessDeniedReason = "CSRFValidationFilter: ORIGIN and REFERER request headers are both absent/empty so we block the request !";
				httpResp.sendError(HttpServletResponse.SC_FORBIDDEN, accessDeniedReason);
				return;
			}
		}

		//Compare the source against the expected target origin
		URL sourceURL = new URL(source);
		System.out.println(sourceURL.getHost());
		System.out.println(sourceURL.getProtocol());

		if (!this.targetOrigin.getProtocol().equals(sourceURL.getProtocol()) || !this.targetOrigin.getHost().equals(sourceURL.getHost()) 
				|| this.targetOrigin.getPort() != sourceURL.getPort()) {
			accessDeniedReason = String.format("CSRFValidationFilter: Protocol/Host/Port do not fully matches so we block the request! (%s != %s) ", 
					this.targetOrigin, sourceURL);
			httpResp.sendError(HttpServletResponse.SC_FORBIDDEN, accessDeniedReason);
			return;
		}
		chain.doFilter(request, response);
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		try {
			this.targetOrigin = new URL("http://localhost:8080");
		} catch (MalformedURLException e) {
			throw new ServletException(e);
		}
	}

	private boolean isBlank(String s) {
		return s == null || "null".equals(s) ||s.trim().isEmpty();
	}
}
